import { Subscription } from 'rxjs/Subscription';
export declare class SidebarService {
    private _openObserver;
    private _closeObserver;
    open(): void;
    close(): void;
    onOpen(fn: () => void): Subscription;
    onClose(fn: () => void): Subscription;
}
