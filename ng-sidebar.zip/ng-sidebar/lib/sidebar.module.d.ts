import { ModuleWithProviders } from '@angular/core';
export declare class SidebarModule {
    static forRoot(): ModuleWithProviders;
    constructor(parentModule: SidebarModule);
}
