import { AfterContentInit, ChangeDetectorRef, EventEmitter, OnChanges, OnDestroy, SimpleChanges, QueryList } from '@angular/core';
import { Sidebar } from './sidebar.component';
export declare class SidebarContainer implements AfterContentInit, OnChanges, OnDestroy {
    private _ref;
    backdropClass: string;
    allowSidebarBackdropControl: boolean;
    showBackdrop: boolean;
    showBackdropChange: EventEmitter<boolean>;
    /** @internal */
    _sidebars: QueryList<Sidebar>;
    constructor(_ref: ChangeDetectorRef);
    ngAfterContentInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    /**
     * @internal
     *
     * Computes `margin` value to push page contents to accommodate open sidebars as needed.
     *
     * @return {CSSStyleDeclaration} margin styles for the page content.
     */
    _getStyles(): CSSStyleDeclaration;
    /**
     * Subscribes from all sidebar events to react properly.
     */
    private _subscribe();
    /**
     * Unsubscribes from all sidebars.
     */
    private _unsubscribe();
    /**
     * Triggers change detection to recompute styles.
     */
    private _markForCheck();
    /**
     * Check if we should show the backdrop when a sidebar is toggled.
     */
    private _onToggle();
}
