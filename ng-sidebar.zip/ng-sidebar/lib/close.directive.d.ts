import { SidebarService } from './sidebar.service';
export declare class CloseSidebar {
    private _sidebarService;
    constructor(_sidebarService: SidebarService);
    /** @internal */
    _onClick(): void;
}
